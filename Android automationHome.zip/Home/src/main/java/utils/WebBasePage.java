package utils;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.IExtentTestClass;
import com.relevantcodes.extentreports.LogStatus;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.util.Strings;

import java.util.List;

import static reporting.ReportFactory.getTest;

public class WebBasePage {

    public WebDriverWait wait;
    private final static String FILE_NAME =System.getProperty("user.dir") +"src/main/resources/testdata.properties";
    public ExtentTest test;
    public static AndroidDriver<MobileElement> driver;
    public WebBasePage(AndroidDriver<MobileElement> driver){this.driver=driver;}

    public Boolean isVisible(By by,int timeInsec)
    {
        boolean result=false;
        try
        {
            wait=new WebDriverWait(driver,timeInsec);
            wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(by));
            result=true;
        }
        catch (Throwable e)
        {

        }
        return result;
    }

    public void click(By by,String name,int timeInSec)
    {
      try
      {
          wait=new WebDriverWait(driver,timeInSec);
          wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(by));
          driver.findElement(by).click();
          getTest().log(LogStatus.PASS,name +"is Clicked");

      }catch (Throwable e)
      {
          getTest().log(LogStatus.FAIL,name +"is not clicked" +e);
          Assert.fail(name +"is not clicked" +e);
      }

    }
    public void clickFromList(By by ,String expectedText,String attribute,String name ,int timeInSec)
    {
       String value;
       Boolean result=false;
        List<MobileElement> elements=driver.findElements(by);
        for(MobileElement find:elements)
        {
         value=find.getAttribute(attribute).trim();
         if(Strings.isNotNullAndNotEmpty(value))
         {
          if(value.equalsIgnoreCase(expectedText.trim()))
           {   result=true;
               find.click();
               getTest().log(LogStatus.PASS,name +"is clicked");
               break;
           }
         }
         }
        if (!result)
        {
         getTest().log(LogStatus.FAIL,name + "is not clicked");
         Assert.fail(name +"is not clicked");
        }

}


}
