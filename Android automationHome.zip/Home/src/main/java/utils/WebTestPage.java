package utils;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;

import java.io.BufferedReader;
import java.io.FileReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

import static reporting.ReportFactory.closeReport;


public class WebTestPage {

    public static AndroidDriver<MobileElement> driver;
    public static ExtentTest test;
    public static ExtentReports report;

   @BeforeClass
   public void setup() throws MalformedURLException
   {
     DesiredCapabilities DC = new DesiredCapabilities();
       DC.setCapability("deviceName","Galaxy S21 FE 5G");
       DC.setCapability("platformName","Android");
       DC.setCapability("platformVersion","13");
//     DC.setCapability("deviceName","Nokia G20");
//     DC.setCapability("platformName","Android");
//     DC.setCapability("platformVersion","12");
     driver = new AndroidDriver<>(new URL("http://127.0.0.1:4723/wd/hub"),DC);
   }
    @AfterTest(alwaysRun = true)
    public void close() throws Exception {
        int reportStatusCount;
        String name;
        String status;
        String reportStatus = null;
        int count;
        String reStatus;
        String timeStamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
        //  String zipPath = System.getProperty("user.dir")+"/reportZip/" +testClassName+ "ReportsZip "+timeStamp+" .zip";
        String reportsPath = System.getProperty("user.dir") + "/reports";
        closeReport();
        //FolderZip.zipFolder(reportsPath, zipPath);
        try {
            FileReader fr = new FileReader("reports/AutomationReport.html");
            BufferedReader br = new BufferedReader(fr);
            StringBuilder html = new StringBuilder();
            String val;
            while ((val = br.readLine()) != null) {
                html.append(val);
            }
            String result = html.toString();
            Document document = (Document) Jsoup.parse(result);
            Elements testName = document.select("span.test-name");
            Elements testStatus = document.select("span.test-status");
            reportStatusCount = testName.size();
            String header[] = new String[reportStatusCount];
            for (count = 0; count < reportStatusCount; count++) {
                name = testName.get(count).text();                status = testStatus.get(count).text();
                reStatus = name + "->" + status;
                header[count] = reStatus;
                reportStatus = Arrays.toString(header).replace("[", "").replace("]", "").replace(",", "\r\n");
            }
            br.close();
            //FolderZip.zipFolder(reportsPath, zipPath);
            //   new HtmlEmailSender().sendFailMail(prop.getProperty("reportMailAddress"), "Automation Test Result", zipPath, reportStatus);
        } catch (Exception e) {
        }
    }

}
