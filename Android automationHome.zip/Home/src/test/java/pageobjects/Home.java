package pageobjects;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.WebDriverWait;
import utils.PropertiesLoader;
import utils.WebBasePage;

import java.util.Date;
import java.util.Properties;

import static reporting.ReportFactory.getTest;

public class Home extends WebBasePage {

    private static final String File_Name=System.getProperty("user.dir") +"/src/main/resources/testdata.properties";
    private static Properties prop=new PropertiesLoader(File_Name).load();
    public static AndroidDriver<MobileElement> driver;
    public static WebDriverWait wait;
    ExtentTest test;

public Home(AndroidDriver<MobileElement> driver)
{
super(driver);
this.driver=driver;

}

    public void home() throws InterruptedException
    {
//       test=getTest("Mobile Home test");
//       test.setStartedTime(new Date());
//       getTest().log(LogStatus.PASS," Elements are navigated");

        click(By.xpath("//android.widget.FrameLayout[@content-desc='Home']/android.widget.ImageView"), "User is in HomePage", 120);
        System.out.println("User is in Home Page");
        clickFromList(By.xpath("//android.widget.FrameLayout//android.view.ViewGroup/android.widget.Button"),"featured","text"," feature tab",15);
        clickFromList(By.xpath("//android.widget.FrameLayout//android.view.ViewGroup/android.widget.Button"),"recently uploaded","text","user is in recently uploaded page",15);
        clickFromList(By.xpath("//android.widget.FrameLayout//android.view.ViewGroup/android.widget.Button"),"popular","text","User is in popular tab",15);
        System.out.println("Home page tabs are navigated");

    }

}
