package test;

import com.relevantcodes.extentreports.ExtentTest;
import org.testng.annotations.Test;
import utils.WebTestPage;

import static reporting.ReportFactory.getTest;

public class Home extends WebTestPage {

ExtentTest test;
@Test
public void homePage() throws InterruptedException
{
    pageobjects.Home hp=new pageobjects.Home(driver);
    test=getTest("Mobile Home test");
    hp.home();

}

}
