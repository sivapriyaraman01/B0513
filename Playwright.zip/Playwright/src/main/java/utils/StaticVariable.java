package utils;

public class StaticVariable {
    public static String dPForm;

}
