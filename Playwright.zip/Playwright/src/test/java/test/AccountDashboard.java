package test;

import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;

public class AccountDashboard {
    public static void main(String[] args) {
        try (Playwright playwright = Playwright.create()) {
            Page page = playwright.chromium().launch(new BrowserType.LaunchOptions()
                    .setHeadless(false)).newPage();
            //page.viewportSize();
            page.setViewportSize(1366,768);
            page.navigate("https://test.salesforce.com/");
            //page.navigate("https://tela3--demobox.sandbox.lightning.force.com/");
            page.locator("//input[@id=\"username\"]").click();
            page.locator("//input[@id=\"username\"]").fill("telabiormadmin@setvi.com.demobox");
            page.getByLabel("Password").fill("J6kyBRPT3E@7");
            page.locator("#Login").click();
            page.waitForTimeout(3000);
            page.frameLocator("//iframe[@title='dashboard']").locator("//button[@class='slds-button slds-button_neutral refresh']").click();
            //page.locator("//button[@class='slds-button slds-button_neutral refresh']").click();
            System.out.println("Home page is refreshed");

//            page.locator("//span[@class='slds-truncate'][text()='Account Dashboard']").click();
//            page.pause();
//            page.locator("//input[@placeholder='Search']").click();
//            page.locator("//input[@placeholder='Search']").fill("Alicia Manning");
//            page.keyboard().press("Enter");
//            System.out.println("Search result is displayed");
//            page.locator("//input[@placeholder='Search']").clear();
//            System.out.println("Search field is cleared");
//            page.locator("//div[@data-id='BrandName']").click();
//            System.out.println("By Brand field is clicked");
//            page.locator("//ul//li[text()='Total']").click();
//            System.out.println("Total by brand is selected");
//            page.locator("//div[@data-id='TimePeriod']").click();
//            System.out.println("By time period field is clicked");
//            page.locator("//li[@data-value='YTD']").click();
//            System.out.println("YTD time period is selected");
//            page.locator("//div[@data-id='SalesUnits']").click();
//            System.out.println("Salesunit field is clicked");
//            page.locator("//li[@data-value='Units']").click();
//            System.out.println("unit is selected from sales/units");
//            page.locator("//button[text()='Export']").click();
//            page.waitForTimeout(3000);
//            System.out.println("File is exported successfully");

}}}

