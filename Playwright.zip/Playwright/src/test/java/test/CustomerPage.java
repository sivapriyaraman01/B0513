package test;

import com.microsoft.playwright.*;
import com.microsoft.playwright.options.ViewportSize;


public class CustomerPage {

    public static void main(String[] args) {
        try (Playwright playwright = Playwright.create()) {
            Page page = playwright.chromium().launch(new BrowserType.LaunchOptions()
                    .setHeadless(false)).newPage();
            //page.viewportSize();
            page.setViewportSize(1366,768);
            page.navigate("https://tela3--demobox.sandbox.lightning.force.com/");
            page.locator("//input[@id=\"username\"]").click();
            page.locator("//input[@id=\"username\"]").fill("telabiormadmin@setvi.com.demobox");
            page.getByLabel("Password").fill("J6kyBRPT3E@3 ");
            page.locator("#Login").click();
            page.locator("//span[@class='slds-truncate'][text()='Customers']").click();


            System.out.println("User navigated into the Customer page");
            page.locator("//button[@class=\"slds-button\"][text()=\"View All\"]").click();

            //page.locator("//span[@class=\"slds-truncate\"][text()=\"Recently Viewed\"][1]").click();
           // page.locator("//button[@class=\"slds-button\"][text()=\"View All\"]").click();
          // page.locator(" //select[@name='optionSelectGPO']").click();
            //page.pause();
            page.locator("//select[@name='optionSelectGPO']").selectOption("Allegheny Health Network");
            page.locator("//select[@name='optionSelect']").selectOption("This Month");

//            page.click("page.locator(\"select[name=\\\"optionSelectGPO\\\"]\").selectOption(\"Allegheny Health Network\")");
            page.waitForTimeout(1000);
            page.locator("//span[@class='slds-truncate'][text()='Customers']").click();
            page.locator("//select[@name='optionSelect']").selectOption("Custom Date");
            page.locator("//input[@name='FromDate']").click();
            page.locator("//input[@name='FromDate']").fill("Oct 6, 2022");
            page.locator("//input[@name='ToDate']").fill("Dec 10, 2022");
           // page.pause();
            page.locator("//input[@placeholder=\"Search\"]").fill("Abrazo Central Campus");
            page.keyboard().press("Enter");
           // page.keyboard.press('Enter');
            page.waitForTimeout(2000);
            page.locator("//button[@class='slds-input__icon slds-input__icon_right slds-button slds-button_icon']").click();
            System.out.println("Search result is displayed");
            page.isVisible("//div[text()='Revenue']");
            System.out.println("Revenue Field is displayed for searched result");
            if(page.isVisible("//div[text()='Total Customers']"))
            System.out.println("Total customer field is displayed in the customer page");
            else
            System.out.println("Total customer field is not displayed in the customer page");
           // page.pause();
            if(page.isVisible("//div[text()='New Customers']"))
                System.out.println("New Customer field is displayed in the customer page");
            else
                System.out.println("New Customer field is not displayed in the customer page");
            if(page.isVisible("//span[@title='Name']"))
                System.out.println("Customer Name field is displayed");
            else
                System.out.println("Customer Name field is not displayed");
           // page.pause();
            page.locator("//span[@title='Name']").click();
            page.locator("//span [text()='Name']//..//lightning-primitive-icon[@class='slds-icon_container']").click();
            System.out.println("Customer Name is sorted");
            page.waitForTimeout(1000);
            if(page.isVisible("//span[text()='Revenue']"))
                System.out.println("Revenue field is displayed");
            else
                System.out.println("Revenue field is not displayed");
            page.locator("//span[@title='Revenue']").click();
            page.locator("//span[text()='Revenue']//..//lightning-primitive-icon[@class='slds-icon_container']").click();
            System.out.println("Revenue Field value is sorted");
            if(page.isVisible("//span[text()='OviTex']"))
                System.out.println("OviText field is displayed");
            else
                System.out.println("OviText field is not displayed");
            //page.pause();
            page.locator("//span[@title='OviTex']").click();
            page.locator("//span[text()='OviTex']//..//lightning-primitive-icon[@class='slds-icon_container']").click();
            System.out.println("OviTex field is Sorted");
            if(page.isVisible("//span[text()='OviTex PRS']"))
                System.out.println("OviTex PRS field is displayed");
            else
                System.out.println("OviTex PRS field is not displayed");
           // page.pause();
            page.locator("//span[text()='OviTex PRS']").click();
            page.locator("//span[text()='OviTex PRS']//..//lightning-primitive-icon[@class='slds-icon_container']").click();
            System.out.println("OviTex PRS field is sorted");
            page.waitForTimeout(2000);
            if(page.isVisible("//span[text()='Location']"))
                System.out.println("Location Field is displayed");
            else
                System.out.println("Location field is not displayed");
            page.locator("//span[text()='Location']").click();
            page.locator("//span[text()='Location']//..//lightning-primitive-icon[@class='slds-icon_container']").click();
            System.out.println("Location field is sorted");
            page.waitForTimeout(2000);
            if(page.isVisible("//span[text()='Contract Group']"))
                System.out.println("Contract Group field is displayed");
            else
                System.out.println("Contract Group field is not displayed");
            page.locator("//span[text()='Contract Group']").click();
            page.locator("//span[text()='Contract Group']//..//lightning-primitive-icon[@class='slds-icon_container']").click();
            System.out.println("Contract Group field is sorted");
            if(page.isVisible("//span[text()='Rep Name']"))
                System.out.println("Rep Name field is displayed");
            else
                System.out.println("Rep Name field is not displayed");
            page.locator("//span[text()='Rep Name']").click();
            page.waitForTimeout(2000);
            page.locator("//span[text()='Rep Name']//..//lightning-primitive-icon[@class='slds-icon_container']").click();
            System.out.println("Rep Name field is Sorted");
            if(page.isVisible("//span[text()='Customer Since']"))
                System.out.println("Customer Since field is displayed");
            else
                System.out.println("Customer Since field is not displayed");
            page.locator("//span[text()='Customer Since']").click();
            page.waitForTimeout(2000);
            page.pause();
            page.locator("//span[text()='Customer Since']//..//lightning-primitive-icon[@class='slds-icon_container']").click();
            System.out.println("Customer Since Field is sorted");
            page.pause();
            page.locator("//span[text()='Name']").click();
            page.locator("//span[text()='Name']//..//lightning-primitive-icon[@class='slds-icon_container']").click();
            page.waitForTimeout(2000);
            page.locator("//div[@class='slds-truncate']//..//a[text()='Yellowstone Surgery Center']").click();
            System.out.println("Customer detail page is opened");
            page.pause();

            if(page.isVisible("//li[@class='slds-tabs_default__item']/a[text()='Interactions']"))
                System.out.println("Interactions tab is visible");
            else
                System.out.println("Interactions tab is not visible");
            page.locator("//li[@class='slds-tabs_default__item']/a[text()='Interactions']").click();
            System.out.println("User navigated to interactions page");
            if(page.isVisible("//li[@class='slds-tabs_default__item']/a[text()='Details']"))
                System.out.println("Details tab is displayed");
            else
                System.out.println("Details tab is not displayed");
            page.locator("//li[@class='slds-tabs_default__item']/a[text()='Details']").click();
            System.out.println("User navigated into the details page");
            if(page.isVisible("//li[@class='slds-tabs_default__item']/a[text()='Contacts (0)']"))
                System.out.println("Contacts tab is displayed");
            else
                System.out.println("Contacts tab is not displayed");
            if(page.isVisible("//li[@class='slds-tabs_default__item']/a[text()='Files (0)']"))
                System.out.println("Files tab is displayed");
            else
                System.out.println("Files tab is not displayed");
            page.waitForTimeout(3000);
            if(page.isVisible("//li[@class='slds-tabs_default__item']/a[text()='Price Lists (70)']"))

                System.out.println("Price List tab is displayed");
            else
            System.out.println("Price tab is not displayed");
            page.locator("//li[@class='slds-tabs_default__item']/a[text()='Price Lists (70)']").click();
            System.out.println("User navigated into the Price list page");
            if(page.isVisible("//li[@class='slds-tabs_default__item']/a[text()='Invoices']"))
                System.out.println("Invoice tab is displayed");
            else
                System.out.println("Invoice tab is not displayed");
            page.locator("//li[@class='slds-tabs_default__item']/a[text()='Invoices']").click();
            System.out.println("User navigated into the Invoices page");
            if(page.isVisible("//li[@class='slds-tabs_default__item']/a[text()='Inventory']"))
                System.out.println("Inventory page is displayed");
            else
                System.out.println("Inventory page is not displayed");
            page.locator("//li[@class='slds-tabs_default__item']/a[text()='Inventory']").click();
            System.out.println("User navigated into the Inventory page");
            page.waitForTimeout(3000);
            if(page.isVisible("//li//button[text()='Export']"))
                System.out.println("Export button is visible");
            else
                System.out.println("Export button is not visible");
            page.locator("//li//button[text()='Export']").click();
            System.out.println("User exported the file");


        }

        }
    }