package test;

import com.microsoft.playwright.*;

import java.text.SimpleDateFormat;

import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;
import static java.lang.System.out;
import static utils.StaticVariable.dPForm;

public class DPform {
   public static void main(String[] args){
//    public void dpFormMethod() {
        String timeStamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new java.util.Date());

       dPForm = "automationform" + timeStamp;

        try (Playwright playwright = Playwright.create()) {
            Page page = playwright.chromium().launch(new BrowserType.LaunchOptions()
                    .setHeadless(false)).newPage();
            page.navigate("https://tela3--demobox.sandbox.lightning.force.com/");

            page.locator("//input[@id=\"username\"]").click();
            page.locator("//input[@id=\"username\"]").fill("telabiormadmin@setvi.com.demobox");

            page.getByLabel("Password").fill("J6kyBRPT3E@3");
            page.locator("#Login").click();
            //page.pause();

            page.locator("text=MoreShow More").click();

            page.locator("text=Delivered Products").nth(2).click();
            assertThat(page).hasURL("https://tela3--demobox.sandbox.lightning.force.com/lightning/o/Delivered_Product__c/list?filterName=Recent");

//            Page page = page.waitForPopup(() -> {
//                page.locator("a[role=\"button\"]:has-text(\"New Form\")").click();
//            });
//            assertThat(page).hasURL("https://tela3--tbpartial.sandbox.lightning.force.com/lightning/o/Delivered_Product__c/list?filterName=Recent");
            page.navigate("https://tela3--demobox.sandbox.lightning.force.com/lightning/n/Delivered_Products");
           page.waitForTimeout(3000);
          // page.pause();
           page.locator("//input[@name='FormName']").isVisible();

            System.out.println("Form Name field is visible");
            page.locator("//input[@name='FormName']").click();
            page.locator("//input[@name='FormName']").fill(dPForm);
            page.locator("select[name=\"optionsAccountManager\"]").selectOption("0055e000006EYCVAA4");
            page.locator("//label[text()='Customer']/..//span[contains(text(),'Select')]").click();
            page.locator("//div[@class='search-dropdown-list']//li[text()='CK Surgical (CKS001)']").click();
            page.getByText("CK Surgical (CKS001)").click();
            page.locator("//label[text()='Site']/..//span[contains(text(),'Select')]").click();
            page.getByText("Adam King (R1500)").click();
            page.locator("//input[@name='PO']").click();
            page.locator("//input[@name='PO']").fill("auto test");
            page.waitForTimeout(3000);
            page.pause();
            page.locator("select[name=\"optionsTechnique\"]").selectOption("a158D000000p8Z2QAI");
            page.locator("select[name=\"optionsHerniaType\"]").selectOption("a158D000000p8Z4QAI");
            page.locator("select[name=\"optionsPlacementOfDevice\"]").selectOption("a158D000000p8ZBQAY");
            page.locator("select[name=\"optionsComponentSeparation\"]").selectOption("a158D000000p8ZEQAY");
            page.locator("select[name=\"optionsPrimaryClousureObtained\"]").selectOption("a158D000000p8ZHQAY");
            page.locator("select[name=\"optionsRecurrentHernia\"]").selectOption("a158D000000p8ZIQAY");
            page.locator("//input[@name='SurgeryDate']").fill("FEB 27, 2023");

            page.getByPlaceholder("Last Name, First Name").click();
            page.getByPlaceholder("Last Name, First Name").fill("auto tester");
            page.getByPlaceholder("Last Name, First Name").click();
            page.waitForTimeout(2000);
            page.locator("select[name=\"ReplenishmentRequired\"]").selectOption("a158D000000p8ZKQAY");
            page.locator("select[name=\"optionsCatalogNumber\"]").selectOption("01t5e000002XMnzAAG");
            page.locator("select[name=\"optionsLot\"]").selectOption("ERT-21H08");
            page.locator("//input[@name='qty']").focus();
            page.waitForTimeout(2000);


            page.locator("//input[@name='qty']").focus();
            page.waitForTimeout(2000);
            page.type("//input[@name='qty']", "1");
            page.waitForTimeout(2000);

            page.locator("//input[@name='unitPrice']").click();
            page.locator("//span[@class='oval' and text()='+']").click();
            page.locator("(//select[@name=\"optionsCatalogNumber\"])[2]").selectOption("01t5e000002XMnyAAG");
            page.locator("(//select[@name=\"optionsLot\"])[2]").selectOption("ERT-21K29");
            page.locator("(//input[@name='qty'])[2]").focus();
            page.waitForTimeout(2000);
            page.type("(//input[@name='qty'])[2]", "1");
            page.locator("(//span[@class='oval' and text()='+'])[2]").click();
            page.pause();
            page.locator("(//span[@class='oval' and text()='-'])[3]").click();
            page.locator("//input[@name='Comments']").click();
            page.locator("//input[@name='Comments']").fill("playwright test form");
            page.locator("(//button[@type='button' and text()='Preview'])[2]").click();
            page.waitForTimeout(9000);
            page.locator("(//button[@type='button' and text()='Submit'])[1]").click();
            page.locator("//button[@class='slds-button slds-button_success' and text()='Yes']").click();
            out.println("Form submitted successfully ");
            page.waitForTimeout(2000);
            page.pause();
            // boolean form= page.isVisible("(//span[@class='slds-truncate uiOutputText'])[1]");
            // page.isVisible("//span[text(),'"+formName+"']");
            page.isVisible("//span[text()='" + dPForm + "']");
            // page.pause();
            out.println("submitted Form successfully Verified");
            page.waitForTimeout(2000);
            page.pause();
            if (page.isVisible("//div[contains(@class,'headerTrigger ')]//lightning-icon[contains(@class,'slds-icon-utility-setup')]//ancestor::a"))
                out.println("Element is visible");
            else out.println("Element not visible");
            // page.locator("//div[contains(@class,'headerTrigger ')]//lightning-icon[contains(@class,'slds-icon-utility-setup')]//ancestor::a").click();
            //page.locator("//div[contains(@class,'headerTrigger ')]//lightning-icon[contains(@class,'slds-icon-utility-setup')]").click();
            page.pause();
            // page.locator("//li[@class='slds-global-actions__item slds-dropdown-trigger slds-dropdown-trigger--click']//lightning-message-context-consumer[@class='setupGear']").click();
            // page.locator("//div[@class=' setupGear']").click();
            // System.out.println("Setup gear is clicked");


            // "//span[contains(text(),'"+formname+"')]"
            // page.locator(".slds-input").first().type(formName);
            // page.keyboard().press("Enter");
            // page.locator("//span[@data-aura-class='uiOutputText']").first().highlight();
            // System.out.println(" Form successfully submitted ");


        }

    }
}
