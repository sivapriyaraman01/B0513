package test;

import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import com.microsoft.playwright.options.AriaRole;
import org.testng.annotations.Test;

public class DemoTest {

    @Test
    public void refreshTest1() {
        try (Playwright playwright = Playwright.create()) {
            Page page = playwright.chromium().launch(new BrowserType.LaunchOptions()
                    .setHeadless(false)).newPage();
            page.navigate("https://test.salesforce.com/");
            page.locator("//input[@id=\"username\"]").click();
            page.locator("//input[@id=\"username\"]").fill("telabiormadmin@setvi.com.demobox");
            page.getByLabel("Password").fill("J6kyBRPT3E@7 ");
            page.locator("#Login").click();
            page.waitForTimeout(5000);
            page.locator("//div[contains(@class,'headerTrigger ')]//lightning-icon[contains(@class,'slds-icon-utility-setup')]//ancestor::a").click();
            System.out.println("Setup gear is clicked");
            Page page1 = page.waitForPopup(() -> {
                page.getByRole(AriaRole.MENUITEM, new Page.GetByRoleOptions().setName("Setup Opens in a new tab")).click();
            });

            page1.url();
            page1.locator("(//ul[@class='slds-tree setup-tree']//div[@title='Users']//button)[1]").click();
            page1.locator("//a[@href='/one/one.app#/setup/ManageUsers/home']").click();
            System.out.println("Navigated to user page");
            page1.waitForLoadState();
            page1.waitForTimeout(13000);
            int count = page1.frameLocator("//iframe[@title='All Users ~ Salesforce - Enterprise Edition']").locator("//table[@class='list']//a[text()='Login']").count();
            System.out.println("the element is " + count);
            for (int i = 50; i <= 55; i++) {
                try {
                    System.out.println("Page 1 started ----------");
                    page1.waitForTimeout(12000);
                    page1.frameLocator("//iframe[@title='All Users ~ Salesforce - Enterprise Edition']").locator("(//table[@class='list']//a[text()='Login'])" + "[" + i + "]").click();
                    page1.waitForTimeout(20000);
                    page1.frameLocator("//iframe[@title='dashboard']").locator("//button[@class='slds-button slds-button_neutral refresh']").click();
                    page1.waitForTimeout(8000);
                    String AM1 = page1.waitForSelector("//div[@data-message-id='loginAsSystemMessage']").textContent();
                    page1.waitForSelector("//a[@href='/secur/logout.jsp']").click();
                    System.out.println(i + " " + AM1);
                    page1.waitForTimeout(8000);
                    System.out.println(AM1 + "board refreshed");
                    System.out.println("Page 1 ended ----------");
                } catch (Exception e) {

                }
                try {
                    System.out.println("Page 2 started ----------");
                    Page page2 = page.waitForPopup(() -> {
                        page.getByRole(AriaRole.MENUITEM, new Page.GetByRoleOptions().setName("Setup Opens in a new tab")).click();
                    });
                    page2.waitForTimeout(12000);
                    page2.frameLocator("//iframe[@title='All Users ~ Salesforce - Enterprise Edition']").locator("(//table[@class='list']//a[text()='Login'])" + "[" + i + "]").click();
                    page2.waitForTimeout(20000);
                    page2.frameLocator("//iframe[@title='dashboard']").locator("//button[@class='slds-button slds-button_neutral refresh']").click();
                    page2.waitForTimeout(8000);
                    String AM2 = page2.waitForSelector("//div[@data-message-id='loginAsSystemMessage']").textContent();
                    page2.waitForSelector("//a[@href='/secur/logout.jsp']").click();
                    System.out.println(i + " " + AM2);
                    page2.waitForTimeout(8000);
                    System.out.println(AM2 + "board refreshed");
                    System.out.println("Page 2 ended ----------");
                } catch (Exception e) {

                }
            }

            }

        }
    }