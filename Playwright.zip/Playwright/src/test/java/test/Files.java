package test;

import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;

import java.nio.file.Paths;

public class Files {
    public static void main(String[] args) {
        try (Playwright playwright = Playwright.create()) {
            Page page = playwright.chromium().launch(new BrowserType.LaunchOptions()
                    .setHeadless(false)).newPage();
            //page.viewportSize();
            page.setViewportSize(1366, 768);
            page.navigate("https://tela3--demobox.sandbox.lightning.force.com/");
            page.locator("//input[@id=\"username\"]").click();
            page.locator("//input[@id=\"username\"]").fill("telabiormadmin@setvi.com.demobox");
            page.getByLabel("Password").fill("J6kyBRPT3E@3 ");
            page.locator("#Login").click();
            page.pause();
            page.locator("text=MoreShow More").click();
           if(page.isVisible("//one-app-nav-bar-menu-item//span[text()='Files']"))
               page.locator("//one-app-nav-bar-menu-item//span[text()='Files']").click();
           page.pause();

            System.out.println("User navigated into the files tab");
            page.locator("//a[@title='Upload Files']").click();
          page.setInputFiles("//a[@title='Upload Files']", Paths.get("Free_Test_Data_1MB_DOCX-1"));
            System.out.println("File is uploaded successfully");


        }
    }
}
