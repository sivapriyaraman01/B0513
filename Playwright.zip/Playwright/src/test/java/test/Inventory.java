package test;

import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;

public class Inventory {


    public static void main(String[] args) {
        new DPform();
        try (Playwright playwright = Playwright.create()) {
            Page page = playwright.chromium().launch(new BrowserType.LaunchOptions()
                    .setHeadless(false)).newPage();
            page.navigate("https://tela3--tbpartial.sandbox.lightning.force.com/");

            page.locator("//input[@id=\"username\"]").click();
            page.locator("//input[@id=\"username\"]").fill("telabiormadmin@setvi.com.tbpartial");

            page.getByLabel("Password").fill("J6kyBRPT3E@5 ");
            page.locator("#Login").click();
            page.waitForTimeout(2000);
            page.locator("//span[@class=\"slds-truncate\" and text()=\"Inventory\"]").click();
            page.waitForTimeout(2000);
            page.locator("//span[text()='By Product Name:']//..//span[@class=\"dynamic-value\"]").click();
           // page.locator("//span[text()='By Product Name:']").click();
            page.locator("//li[text()='OviTex 1S Permanent 10x12']").click();
            System.out.println("By product name filter is selected");



}}}

