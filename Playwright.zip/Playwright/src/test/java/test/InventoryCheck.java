package test;

import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import com.microsoft.playwright.options.AriaRole;
import jdk.jfr.StackTrace;
import org.testng.annotations.Test;

public class InventoryCheck {
@Test
    public static void main(String[] args) {
        try (Playwright playwright = Playwright.create()) {
            Page page = playwright.chromium().launch(new BrowserType.LaunchOptions()
                    .setHeadless(false)).newPage();
            page.navigate("https://tela3--demobox.sandbox.lightning.force.com/");

            page.locator("//input[@id=\"username\"]").click();
            page.locator("//input[@id=\"username\"]").fill("telabiormadmin@setvi.com.demobox");

            page.getByLabel("Password").fill("J6kyBRPT3E@4 ");
            page.locator("#Login").click();
            page.waitForTimeout(3000);
            System.out.println("User log into demobox successfully");
            page.locator("//div[@class='slds-icon-waffle']").click();
            page.locator("//input[@placeholder='Search apps and items...']").fill("Build Request");
            page.locator("//span//p[@class='slds-truncate']").click();
            page.waitForTimeout(2000);
          //  page.locator("//button[@class='slds-button slds-button_brand' and text()='Inventory Check Reminder']").click();
            System.out.println("Inventory check reminder sent to all users");
            //page.waitForTimeout(5000);
            page.locator("//div[contains(@class,'headerTrigger ')]//lightning-icon[contains(@class,'slds-icon-utility-setup')]//ancestor::a").click();
            System.out.println("Setup gear is clicked");
//            page.locator("//a[@role=\"menuitem\"][@title='Setup']").click();
//            page.pause();

            Page page1 = page.waitForPopup(() -> {
                page.getByRole(AriaRole.MENUITEM, new Page.GetByRoleOptions().setName("Setup Opens in a new tab")).click();
        });

            page1.url();
            page1.locator("(//ul[@class='slds-tree setup-tree']//div[@title='Users']//button)[1]").click();

            page1.locator("//a[@href='/one/one.app#/setup/ManageUsers/home']").click();
            page1.waitForTimeout(8000);
            page1.pause();
           // page1.locator("//a[@title='Login - Record 1 - Adamson, Walker']").click();
            page1.frameLocator("//iframe[@title='Active Users ~ Salesforce - Enterprise Edition']").locator("//a[@title='Login - Record 1 - Adamson, Walker']").click();
            page1.waitForTimeout(7000);
            System.out.println("Logged into the AM profile");
            page1.locator("//div[@class='headerButtonBody']").click();
            System.out.println("Notification bell icon is clicked");
            page1.waitForTimeout(5000);
            page1.locator("(//span[@class='notification-text uiOutputText'])[1]").click();
            System.out.println("Inventory reminder check is clicked");
            page1.locator("//a[@class='test-drillin']").click();
            page1.waitForTimeout(5000);
            page1.locator("(//span[@class='slds-truncate' and text()='I have not checked'])[1]").click();
            page1.locator("(//button[@class='slds-button trigger slds-button_icon-border'])[1]").click();
            System.out.println("Edit Inventory is clicked");

        }
    }

}