package test;

import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;

public class Invoicepage {

    public static void main(String[] args) {
        try (Playwright playwright = Playwright.create()) {
            Page page = playwright.chromium().launch(new BrowserType.LaunchOptions()
                    .setHeadless(false)).newPage();
            page.navigate("https://tela3--tbpartial.sandbox.lightning.force.com/");

            page.locator("//input[@id=\"username\"]").click();
            page.locator("//input[@id=\"username\"]").fill("telabiormadmin@setvi.com.tbpartial");

            page.getByLabel("Password").fill("J6kyBRPT3E@5 ");
            page.locator("#Login").click();
            page.waitForTimeout(2000);

            page.locator("//span[@class='slds-truncate' and text()='Invoices']").click();
            // page.waitForTimeout(2000);

            page.locator("//div[@class='dropdown-cont slds-grid slds-grid_vertical-align-center' ]").click();
            page.locator("//ul //li[@data-value='POSTED' and text()='Posted']").click();
            // page.waitForTimeout(2000);

            page.locator("//div[@class='dropdown-cont slds-grid slds-grid_vertical-align-center' ]").click();
            page.locator("//ul //li[@data-value='Pending PO' and text()='Pending PO']").click();
            //page.waitForTimeout(2000);

            page.locator("//div[@class='dropdown-cont slds-grid slds-grid_vertical-align-center' ]").click();
            page.locator("//ul //li[@data-value='All' and text()='All']").click();
            // page.waitForTimeout(2000);
            page.locator("//input[@type='text'][@name='FromDate']  ").click();
            // page.pause();
            page.fill("//input[@name='FromDate']", "Jan 10, 2022");
            page.fill("//input[@name='ToDate']", "Dec 15, 2022");
            //page.pause();
            page.fill("//input[@type='search'] [ @placeholder='Search']", "The Women's Hospital");
            //page.keyboard().press("enter");
            page.waitForTimeout(1000);

            page.locator("//button[@class=\"slds-input__icon slds-input__icon_right slds-button slds-button_icon\"]").click();

            page.locator("//button[@value=\"Refresh\"]").click();
            page.waitForTimeout(3000);
//            page.pause();
            page.locator("(//u[text()='SI025026'])[1]").click();
            page.waitForTimeout(2000);

           // page.locator("//h4[@class=\"section-head relative\"]").isVisible();
            boolean num= page.isVisible("//span[@class=\"header-invoice-number\"]");
            if (num)
                System.out.println("Invoice Number field  is displayed");
            else
                System.out.println("Invoice number field is not displayed");
            page.waitForTimeout(1000);
            boolean date = page.isVisible("//span[text()=\"Date: \"]");
            if (date)

                System.out.println("Date field is displayed");
            else
                System.out.println("Date field is not displayed");
            boolean order = page.isVisible("//h4[@class=\"section-head relative\"]");
            if (order)

                System.out.println("Order Info heading is displayed");
            else
                System.out.println("Order Info heading is not displayed");
            //page.pause();
            boolean PONO = page.isVisible("//span[(@class=\"type-title\") and text()=\"Purchase Order (PO):\"]");
            if(PONO)
                System.out.println("Purchase order number field is displayed");
            else
                System.out.println("Purchase order number field is not displayed");
            boolean POdate = page.isVisible("//span[(@class=\"type-title\") and text()=\"Purchase Order Date:\"]");
            if(POdate)
                System.out.println("Purchase order date field is displayed");
            else
                System.out.println("Purchase order date field is not displayed");
            boolean implant =page.isVisible("//span[(@class=\"type-title\") and text()=\"Implant Date:\"]");
            if (implant)
                System.out.println("Implant date field is displayed");
            else
                System.out.println("Implant date is field not displayed");
            boolean invoicetype= page.isVisible("//span[(@class=\"type-title\") and text()=\"Invoice Type:\"]");
            if(invoicetype)
                System.out.println("Invoice type field  is displayed");
            else
                System.out.println("Invoice type field  is displayed");
            if(page.isVisible("//h4[@class=\"section-head mt-6 relative\"][text()=\"Additional Info\"]"))
                System.out.println("Additional information heading is displayed");
            else
                System.out.println("Additional information heading is not displayed");
            boolean rep= page.isVisible("//h4[@class=\"section-head mt-6 relative\"][text()=\"Rep Info\"]");
            if(rep)
                System.out.println("Rep information heading is displayed");
            else
                System.out.println("Rep information heading is not displayed");
            boolean repname= page.isVisible("//span[@class=\"type-title\"][text()=\"Name:\"]");
            if(repname)
                System.out.println("Repname field is displayed");
            else
            System.out.println("Repname field is not displayed");
            boolean manager= page.isVisible("//span[@class=\"type-title\"][text()=\"Manager:\"]");
            if(manager)
                System.out.println("Manager name field is displayed");
            else
                System.out.println("Manager name field is not displayed");
            boolean item= page.isVisible(" //th[text()=\"Product / Item\"] ");
            if(item)
                System.out.println("Product or Item title is displayed");
            else
                System.out.println("Product or Item title is not displayed");
            boolean qty= page.isVisible(" //th[text()=\"Qty\"]");
            if(qty)
                System.out.println("QTY title is displayed");
            else
                System.out.println("QTY title is not displayed");
            if(page.isVisible("//th[text()=\"Discount\"]"))
                System.out.println("Discount title is displayed");
            else
                System.out.println("Discount title is not displayed");
            if(page.isVisible("//th[text()=\"Net Unit Price\"]"))
                System.out.println("Net Unit Price title is displayed");
            else
                System.out.println("Net Unit Price title is not displayed");
            if(page.isVisible("//th[text()=\"Invoice Line Amt\"]"))
                System.out.println("Invoice line amount title is displayed");
            else
                System.out.println("Invoice line amount title  is not displayed");
            if(page.isVisible("//th[text()=\"Sale Amt\"]"))
                System.out.println("Sale amount title is displayed");
            else
                System.out.println("Sale amount title is not displayed");
            if(page.isVisible("//span[@class='price-value text-right']"))
                System.out.println("Total value is displayed");
            else
                System.out.println("Total value is not displayed");
            boolean close =page.isVisible("svg.cursor-pointer");
                if(close)
                {   page.click("svg.cursor-pointer");
                    System.out.println("Invoice popup is closed");
                } else
                System.out.println("Invoice popup not closed");

            page.pause();
            page.waitForTimeout(30000);
            page.click("//a[@href=\"https://tela3--tbpartial.sandbox.lightning.force.com/0018G00000H0MGFQA3\"]");
             page.pause();
            System.out.println("Page navigated into the Customer page");
            page.pause();


        }
    }
}