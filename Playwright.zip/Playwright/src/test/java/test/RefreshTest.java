package test;

import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import com.microsoft.playwright.options.AriaRole;
import org.testng.annotations.Test;

public class RefreshTest {

    @Test
    public void refreshTest1() {
        try (Playwright playwright = Playwright.create()) {
            Page page = playwright.chromium().launch(new BrowserType.LaunchOptions()
                    .setHeadless(false)).newPage();
            page.navigate("https://test.salesforce.com/");
            page.locator("//input[@id=\"username\"]").click();
            page.locator("//input[@id=\"username\"]").fill("telabiormadmin@setvi.com.demobox");
            page.getByLabel("Password").fill("J6kyBRPT3E@7 ");
            page.locator("#Login").click();
            page.waitForTimeout(5000);
            page.locator("//div[contains(@class,'headerTrigger ')]//lightning-icon[contains(@class,'slds-icon-utility-setup')]//ancestor::a").click();
            System.out.println("Setup gear is clicked");
            Page page1 = page.waitForPopup(() -> {
                page.getByRole(AriaRole.MENUITEM, new Page.GetByRoleOptions().setName("Setup Opens in a new tab")).click();
            });
            page1.url();
            page1.locator("(//ul[@class='slds-tree setup-tree']//div[@title='Users']//button)[1]").click();
            page1.locator("//a[@href='/one/one.app#/setup/ManageUsers/home']").click();
            System.out.println("Navigated to user page");
            page1.waitForLoadState();
            page1.waitForTimeout(13000);
            int count = page1.frameLocator("//iframe[@title='All Users ~ Salesforce - Enterprise Edition']").locator("//table[@class='list']//a[text()='Login']").count();
            System.out.println("the element is " + count);
            for (int i = 1; i <= 4; i++) {
                page1.waitForTimeout(12000);
                page1.frameLocator("//iframe[@title='All Users ~ Salesforce - Enterprise Edition']").locator("(//table[@class='list']//a[text()='Login'])" + "[" + i + "]").click();
                page1.waitForTimeout(20000);
                page1.frameLocator("//iframe[@title='dashboard']").locator("//button[@class='slds-button slds-button_neutral refresh']").click();
                page1.waitForTimeout(8000);
                String AM1 = page1.waitForSelector("//div[@data-message-id='loginAsSystemMessage']").textContent();
                page1.waitForSelector("//a[@href='/secur/logout.jsp']").click();
                System.out.println(i + " " + AM1);
                page1.waitForTimeout(8000);
                System.out.println(AM1 + "board refreshed");

            }

        }
    }

    //    @Test
    public void refreshTest2() {
        try (Playwright playwright = Playwright.create()) {
            Page page = playwright.chromium().launch(new BrowserType.LaunchOptions()
                    .setHeadless(false)).newPage();
            page.navigate("https://test.salesforce.com/");
            page.locator("//input[@id=\"username\"]").click();
            page.locator("//input[@id=\"username\"]").fill("telabiormadmin@setvi.com.demobox");
            page.getByLabel("Password").fill("J6kyBRPT3E@7 ");
            page.locator("#Login").click();
            page.waitForTimeout(5000);
            page.locator("//div[contains(@class,'headerTrigger ')]//lightning-icon[contains(@class,'slds-icon-utility-setup')]//ancestor::a").click();
            System.out.println("Setup gear is clicked");
            Page page1 = page.waitForPopup(() -> {
                page.getByRole(AriaRole.MENUITEM, new Page.GetByRoleOptions().setName("Setup Opens in a new tab")).click();
            });
            page1.url();
            page1.locator("(//ul[@class='slds-tree setup-tree']//div[@title='Users']//button)[1]").click();

            page1.locator("//a[@href='/one/one.app#/setup/ManageUsers/home']").click();
            System.out.println("Navigated to user page");
            page1.waitForLoadState();
            page1.waitForTimeout(13000);
            int count = page1.frameLocator("//iframe[@title='All Users ~ Salesforce - Enterprise Edition']").locator("//table[@class='list']//a[text()='Login']").count();
            System.out.println("the element is " + count);
            for (int i = 49; i <= 96; i++) {
//                page1.waitForTimeout(14000);
                page1.waitForLoadState();
                page1.frameLocator("//iframe[@title='All Users ~ Salesforce - Enterprise Edition']").locator("(//table[@class='list']//a[text()='Login'])" + "[" + i + "]").click();
//                page1.waitForTimeout(13000);
                page1.waitForLoadState();
                page1.waitForTimeout(13000);
                page1.frameLocator("//iframe[@title='dashboard']").locator("//button[@class='slds-button slds-button_neutral refresh']").click();
                page1.waitForLoadState();
                String AM1 = page1.waitForSelector("//div[@data-message-id='loginAsSystemMessage']").textContent();
                page1.waitForSelector("//a[@href='/secur/logout.jsp']").click();

                System.out.println(i + " " + AM1);
//                page1.waitForTimeout(8000);
                page1.waitForLoadState();
                System.out.println(AM1 + "board refreshed");

            }

        }
//    }
//    @Test
//    public void refreshTest3(){
//        try (Playwright playwright = Playwright.create()) {
//            Page page = playwright.chromium().launch(new BrowserType.LaunchOptions()
//                    .setHeadless(false)).newPage();
//            page.navigate("https://test.salesforce.com/");
//            page.locator("//input[@id=\"username\"]").click();
//            page.locator("//input[@id=\"username\"]").fill("telabiormadmin@setvi.com.demobox");
//            page.getByLabel("Password").fill("J6kyBRPT3E@7 ");
//            page.locator("#Login").click();
//            page.waitForTimeout(5000);
//            page.locator("//div[contains(@class,'headerTrigger ')]//lightning-icon[contains(@class,'slds-icon-utility-setup')]//ancestor::a").click();
//            System.out.println("Setup gear is clicked");
//            Page page1 = page.waitForPopup(() -> {
//                page.getByRole(AriaRole.MENUITEM, new Page.GetByRoleOptions().setName("Setup Opens in a new tab")).click();
//            });
//            page1.url();
//            page1.locator("(//ul[@class='slds-tree setup-tree']//div[@title='Users']//button)[1]").click();
//
//            page1.locator("//a[@href='/one/one.app#/setup/ManageUsers/home']").click();
//            System.out.println("Navigated to user page");
//            page1.waitForTimeout(13000);
//            int count=page1.frameLocator("//iframe[@title='All Users ~ Salesforce - Enterprise Edition']").locator("//table[@class='list']//a[text()='Login']").count();
//            System.out.println( "the element is " +count);
//            for (int i = 97; i <= 144; i++) {
//                page1.waitForTimeout(14000);
//                page1.frameLocator("//iframe[@title='All Users ~ Salesforce - Enterprise Edition']").locator("(//table[@class='list']//a[text()='Login'])"+"["+i+"]").click();
//                page1.waitForTimeout(13000);
//                page1.frameLocator("//iframe[@title='dashboard']").locator("//button[@class='slds-button slds-button_neutral refresh']").click();
//                page1.waitForTimeout(7000);
//                String AM1= page1.waitForSelector("//div[@data-message-id='loginAsSystemMessage']").textContent();
//                page1.waitForSelector("//a[@href='/secur/logout.jsp']").click();
//
//                System.out.println(i +" "+AM1);
//                page1.waitForTimeout(8000);
//                System.out.println(AM1+ "board refreshed");
//
//            }
//
//        }
//    }
    }}
