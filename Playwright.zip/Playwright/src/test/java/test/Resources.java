package test;

import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Download;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;

import java.nio.file.Path;
import java.nio.file.Paths;

public class Resources {
    public static void main(String[] args) {
        try (Playwright playwright = Playwright.create()) {
            Page page = playwright.chromium().launch(new BrowserType.LaunchOptions()
                    .setHeadless(false)).newPage();
            //page.viewportSize();
            page.setViewportSize(1366, 768);
            page.navigate("https://tela3--demobox.sandbox.lightning.force.com/");
            page.locator("//input[@id=\"username\"]").click();
            page.locator("//input[@id=\"username\"]").fill("telabiormadmin@setvi.com.demobox");
            page.getByLabel("Password").fill("J6kyBRPT3E@3 ");
            page.locator("#Login").click();
            page.pause();
            page.locator("text=MoreShow More").click();
            page.pause();
            page.locator("//one-app-nav-bar-menu-item//span[text()='Resources']").click();
            System.out.println("User navigated to the resources page");
            Download download = page.waitForDownload(() -> {
                page.locator("(//a[text()='Download'])[1]").click();
            });
            Path path = download.path();
            System.out.println(download.path());
            String df =page.textContent("(//div[@class='slds-col slds-large-size_10-of-12 slds-medium-size_10-of-12 slds-size_10-of-12'])[1]");

            download.saveAs(Paths.get("df.pdf"));
            System.out.println("Resource is downloaded");
            page.pause();
//            Page page1 = page.waitForPopup(() -> {
//                page.locator("//a[text()='Download'])[1]").click();
//            });

        }
    }
}