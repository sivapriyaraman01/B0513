package test;

import com.microsoft.playwright.*;
import com.microsoft.playwright.Locator.LocatorOptions;
import com.microsoft.playwright.options.AriaRole;

import java.text.SimpleDateFormat;
import static utils.StaticVariable.dPForm;

public class SetUp {

    //tr[@data-row-key-value='a0u8G000000jO9KQAU']//td[@data-label='Qty']//lightning-base-formatted-text
    public static void main(String[] args) {

         new DPform();
        try (Playwright playwright = Playwright.create()) {
            Page page = playwright.chromium().launch(new BrowserType.LaunchOptions()
                    .setHeadless(false)).newPage();
            page.navigate("https://test.salesforce.com/");

            page.locator("//input[@id=\"username\"]").click();
            page.locator("//input[@id=\"username\"]").fill("telabiormadmin@setvi.com.demobox");

            page.getByLabel("Password").fill("J6kyBRPT3E@7 ");
            page.locator("#Login").click();
            page.waitForTimeout(5000);
            page.locator("//div[contains(@class,'headerTrigger ')]//lightning-icon[contains(@class,'slds-icon-utility-setup')]//ancestor::a").click();
            System.out.println("Setup gear is clicked");
//            page.locator("//a[@role=\"menuitem\"][@title='Setup']").click();
//            page.pause();

            Page page1 = page.waitForPopup(() -> {
                page.getByRole(AriaRole.MENUITEM, new Page.GetByRoleOptions().setName("Setup Opens in a new tab")).click();
            });
            page1.url();
            page1.locator("(//ul[@class='slds-tree setup-tree']//div[@title='Users']//button)[1]").click();

            page1.locator("//a[@href='/one/one.app#/setup/ManageUsers/home']").click();
            page1.waitForTimeout(9000);
            page1.pause();
            page1.frameLocator("//iframe[@title='All Users ~ Salesforce - Enterprise Edition']").locator("//a[@title='Login - Record 43 - King, Adam']").click();
            page1.waitForTimeout(9000);
            page1.pause();
            System.out.println("Logged into the AM profile");
           // page1.frameLocator("//a[@title='Login - Record 43 - King, Adam']");
            //page1.pause();

           // Frame.ClickOptions(String.valueOf(page1.locator("//a[@title='Login - Record 43 - King, Adam']")));
           // page1.locator("//a[@title='Login - Record 43 - King, Adam']").click();
           // page1.isVisible("//a[@title='Login - Record 43 - King, Adam']");
           // page1.locator("//a[@title='Login - Record 43 - King, Adam']").click();
            page1.waitForTimeout(3000);
//            page1.frameLocator("//iframe[@title='dashboard']").locator("//button[@class='slds-button slds-button_neutral refresh']").click();
//            System.out.println("AM board refreshed");

            page1.locator("//span[text()='Delivered Products']").click();
            page1.locator("//button[@title='Select a List View']").click();


            page1.locator("//span[@class=' virtualAutocompleteOptionText'][text()='All']").click();
            System.out.println("navigate to DP form page");
            page1.pause();
            page1.locator("//input[@placeholder=\"Search this list...\"]").fill(dPForm);
            page1.pause();
            page.keyboard().press("Enter");
            if(page1.isVisible("//span[@class='slds-truncate uiOutputText' and text()='"+dPForm+"']"))
                System.out.println("DP form is visible to AM");
            else
            System.out.println("Submitted DP form is not visible to AM");
            page1.waitForTimeout(2000);

        }

    }
}

