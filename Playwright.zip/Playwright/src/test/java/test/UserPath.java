package test;

public class UserPath {
    public static void main(String[] args) {
        System.out.println(System.getProperty("user.dir"));
    }
}
