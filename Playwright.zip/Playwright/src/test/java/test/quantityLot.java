package test;

import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;

import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;
import static utils.StaticVariable.dPForm;

public class quantityLot {
    public static void main(String[] args){
        String timeStamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());

        String formName = "automationform" + timeStamp;
        dPForm = formName;

        try (Playwright playwright = Playwright.create()) {
            Page page = playwright.chromium().launch(new BrowserType.LaunchOptions()
                    .setHeadless(false)).newPage();
            page.navigate("https://tela3--demobox.sandbox.lightning.force.com/");

            page.locator("//input[@id=\"username\"]").click();
            page.locator("//input[@id=\"username\"]").fill("telabiormadmin@setvi.com.demobox");

            page.getByLabel("Password").fill("J6kyBRPT3E@3");
            page.locator("#Login").click();

            page.locator("text=MoreShow More").click();

            page.locator("text=Delivered Products").nth(2).click();
            assertThat(page).hasURL("https://tela3--demobox.sandbox.lightning.force.com/lightning/o/Delivered_Product__c/list?filterName=Recent");

//            Page page = page.waitForPopup(() -> {
//                page.locator("a[role=\"button\"]:has-text(\"New Form\")").click();
//            });
           // assertThat(page).hasURL("https://tela3--tbpartial.sandbox.lightning.force.com/lightning/o/Delivered_Product__c/list?filterName=Recent");

            page.navigate("https://tela3--demobox.sandbox.lightning.force.com/lightning/n/Delivered_Products");
            page.locator("//input[@name='FormName']").click();
            page.locator("//input[@name='FormName']").fill(dPForm);
            page.locator("select[name=\"optionsAccountManager\"]").selectOption("0055e000006EYCVAA4");
            page.locator("//label[text()='Customer']/..//span[contains(text(),'Select')]").click();
            page.locator("//div[@class='search-dropdown-list']//li[text()='CK Surgical (CKS001)']").click();
            page.getByText("CK Surgical (CKS001)").click();
            page.locator("//label[text()='Site']/..//span[contains(text(),'Select')]").click();
            page.getByText("Adam King (R1500)").click();
            page.locator("//input[@name='PO']").click();
            page.locator("//input[@name='PO']").fill("auto test");
            page.waitForTimeout(2000);
            page.locator("select[name=\"optionsTechnique\"]").selectOption("a158D000000p8Z2QAI");
            page.locator("select[name=\"optionsHerniaType\"]").selectOption("a158D000000p8Z4QAI");
            page.locator("select[name=\"optionsPlacementOfDevice\"]").selectOption("a158D000000p8ZBQAY");
            page.locator("select[name=\"optionsComponentSeparation\"]").selectOption("a158D000000p8ZEQAY");
            page.locator("select[name=\"optionsPrimaryClousureObtained\"]").selectOption("a158D000000p8ZHQAY");
            page.locator("select[name=\"optionsRecurrentHernia\"]").selectOption("a158D000000p8ZIQAY");
            page.locator("//input[@name='SurgeryDate']").fill("FEB 27, 2022");

            page.getByPlaceholder("Last Name, First Name").click();
            page.getByPlaceholder("Last Name, First Name").fill("auto tester");
            page.getByPlaceholder("Last Name, First Name").click();
            page.waitForTimeout(2000);
           // page.pause();
            page.locator("select[name=\"ReplenishmentRequired\"]").selectOption("a158D000000p8ZKQAY");
            page.locator("select[name=\"optionsCatalogNumber\"]").selectOption("01t5e000002XMnzAAG");
            page.locator("select[name=\"optionsLot\"]").selectOption("ERT-21H08");
            page.locator("//select[@name='optionsCatalogNumber']//following::div[2]//p").isVisible();
            System.out.println("Product description OviTex 1S Permanent 10x12 is displayed");
            String product= page.locator("//select[@name='optionsCatalogNumber']//following::div[2]//p").textContent();
            System.out.println(product);
            page.locator("//select[@name='optionsCatalogNumber']//following::div[2]//p//following::div[7]/p").isVisible();
            String str = page.locator("//select[@name='optionsCatalogNumber']//following::div[2]//p//following::div[7]/p").textContent();
            String[] part = str.split("(?<=\\D)(?=\\d)");

             System.out.println(part[0]);
            System.out.println(part[1]);


            String value=String.valueOf(part[1]);
            int value1= Integer.parseInt(value);
            System.out.println(value1);
            page.pause();
            page.navigate("https://tela3--demobox.sandbox.lightning.force.com/lightning/n/Inventory");
            page.locator("//span[@class=\"slds-truncate\" and text()=\"Inventory\"]").click();
            System.out.println("Navigated to Inventory page");

            page.locator("//input[@placeholder='Search']").fill(product);
            page.waitForTimeout(2000);
            page.locator("//span[@title='Site']").click();
            page.pause();
            page.locator("//span[@title='Site']//..//lightning-primitive-icon").click();
            page.waitForTimeout(2000);
            page.locator("//span[@title='Site']//..//lightning-primitive-icon").click();
           // page.locator("(//lightning-primitive-cell-factory//lightning-primitive-custom-cell//div[@class=\"text-sm mb-2\"])[1]//following::div[12]").isVisible();
           // page.locator("//div[text()='Adam Pfeiffer']//following::div[12]").isVisible();
            page.pause();
           page.locator("//tr[@data-row-key-value='a0u8D0000003tciQAA']//td[@data-label='Qty']//lightning-base-formatted-text").isVisible();
            System.out.println("Adam king lot is visible");
            //string inventory=page.locator("(//div[text()='ERT-21H10']//following::div[6])[1]").textContent();
            String inventory=page.locator("//tr[@data-row-key-value='a0u8D0000003tciQAA']//td[@data-label='Qty']//lightning-base-formatted-text").textContent();
            System.out.println(inventory);
           // String value2=inventory.toString();
            //System.out.println(value2);
            //String str1 = inventory;
           // String sample=inventory;
            inventory= inventory.replaceAll("\\(.*?\\)", "");// string outside the parantheses
            System.out.println(inventory);
            String value2=String.valueOf(inventory.trim());
            int value3=Integer.parseInt(value2);
            System.out.println("Inventory value converted into integer");
//            String answer = inventory.substring(inventory.indexOf("(")+1, inventory.indexOf(")"));//string inside  the parantheses
//            System.out.println(answer);
//            int value2=Integer.parseInt(answer);

            System.out.println("value2="+value2+ "value1="+value1);
            if (value1== value3) {
                System.out.println("Available Quantatity in DP form and Inventory page are same");
            }else {
                System.out.println(value1);
                System.out.println(value2);
                System.out.println("Available Quantatity in DP form and Inventory page are not same");
            }

    }}}