package reporting;

public class ComplexReportFactory {
}
