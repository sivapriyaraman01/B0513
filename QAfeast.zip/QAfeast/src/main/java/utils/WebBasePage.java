package utils;

public class WebBasePage {
}
