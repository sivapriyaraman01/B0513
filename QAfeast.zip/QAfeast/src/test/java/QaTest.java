import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.SourceType;
import org.testng.annotations.Test;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;


public class QaTest{

    WebDriver driver;
    //WebElement element;

@Test
public void testrun()  {
  GoTODemo();
  Text();
  Button();
  Radio();
  Check();
  Label();
  Link();
  Dropdown();
  Drag();
  Textmenu();
  Double();
  Frame();
  Windows();
}
public void GoTODemo(){

    System.setProperty("WebDriver.chrome.driver","chromedriver.exe");
    driver=new ChromeDriver();
    driver.manage().timeouts().pageLoadTimeout(60L, TimeUnit.SECONDS);
    driver.get("http://www.qafeast.com/demo");
    driver.manage().window().maximize();
    driver.manage().timeouts().pageLoadTimeout(60L,TimeUnit.MILLISECONDS);

}
public void Text()
{
 driver.findElement(By.xpath("//label[text()='Textbox']"));
 System.out.println("Textbox value is displayed");
    driver.findElement(By.xpath("//h2[@class=\"page-title\" and text()=\"Textbox\"]"));
    System.out.println("TextBox title is displayed");
    boolean display=driver.findElement(By.xpath("//label[text()=\"Editable Text box:\"]")).isDisplayed();
    System.out.println("Enter value in the editable text");

   WebElement element1 = driver.findElement(By.xpath("//label[text()='Editable Text box:'] //..//input[@id='editabletext'] "));
   element1.sendKeys("  abc1233");
    System.out.println("Value entered in the element1");

    WebElement element2=driver.findElement(By.xpath("//label[text()='Not Editable Text box:']//..//input[@id=\"noteditabletext\"]"));
      if(element2.isEnabled())
        System.out.println("Text is editable");
    else
    System.out.println("Non editable textbox");
    String title=driver.findElement(By.xpath("//input[@value='Enter username']/preceding::label[contains(text(),'some')]")).getText();
    System.out.println(title);
//    WebElement toClear = driver.findElement("locator");
//    toClear.sendKeys(Keys.CONTROL + "a");
//    toClear.sendKeys(Keys.DELETE);
    driver.findElement(By.xpath("//input[@id='editabletext' and @value='Enter username']")).clear();
    driver.findElement(By.xpath("//input[@id='editabletext' and @value='Enter username']")).sendKeys("yyxx12345");
    System.out.println("value entered in username field");
}
public void Button()
{
    driver.findElement(By.xpath("//ul//li[@data-number='2']")).click();
    System.out.println("Button is clicked");
    String title=driver.findElement(By.xpath("//div[@id='rghtsideinnerbox_2']/child::h2")).getText();
    System.out.println("The Button page is title is:\n"+title);
    driver.findElement(By.xpath("//button[@title='Click to submit the button']")).click();
    String Submit=driver.findElement(By.xpath("//button[@title='Click to submit the button']/following-sibling::p")).getText();
    System.out.println("The text displayed below the submit button is :\t"  +Submit);
    driver.findElement(By.xpath("//button[@id='button-2']")).click();
    System.out.println("User unable to click order button");
}
//Radio Button
public void Radio()
{
    driver.findElement(By.xpath("//label[text()='Radio Button']")).click();
    System.out.println("Radio button page is displayed");
    driver.findElement(By.xpath("//h2[text()='Radio Button']")).isDisplayed();
    System.out.println("Radio button title is displayed");
    driver.findElement(By.xpath("//input[@class='uncheck'][@value='Male is selected']")).click();
    System.out.println("Select male");
    String m=driver.findElement(By.xpath("//p[@id='msgbutton-2']")).getText();
    System.out.println(m);
    driver.findElement(By.xpath("//input[@name='genderradio'][@value='Female is selected']")).click();
    System.out.println("Select Female");
   String f=driver.findElement(By.xpath("//p[@id='msgbutton-2']")).getText();
    System.out.println(f);

}
//Checkbox
public void Check()
{
    driver.findElement(By.xpath("//li[@data-number=\"4\"]")).click();
    System.out.println("Checkbox is clicked");
    String c=driver.findElement(By.xpath("//div[@class=\"rghtside-inner\" and @id=\"rghtsideinnerbox_4\"] /child::h2")).getText();
    System.out.println("The page title is\t" +c);
    driver.findElement(By.xpath("//input[@value='Summary report']")).click();
    String s=driver.findElement(By.xpath("//div[@id='msgbutton-3']")).getText();
    System.out.println(s);
    driver.findElement(By.xpath("//input[@class='reportchkbox uncheck'][@value='Detailed report']")).click();
    String d=driver.findElement(By.xpath("//div[@id='msgbutton-3']")).getText();
    System.out.println(d);
    driver.findElement(By.xpath("//input[@value='Weekly report']")).click();
    String w=driver.findElement(By.xpath("//div[@id='msgbutton-3']")).getText();
    System.out.println(w);
}
//Label
public void Label() {
    driver.findElement(By.xpath("//li[@data-number='5']")).click();
    String l = driver.findElement(By.xpath("//div[@id='rghtsideinnerbox_5']/child::h2")).getText();
    System.out.println("The page title is\n" + l);
    String t = driver.findElement(By.xpath("//div[@class='label-wrap']/child::h3")).getText();
    System.out.println("Paragraph title is:\n" + t);
    String p = driver.findElement(By.xpath("//div[@class='label-wrap']/child::h3[text()='Test automation']/following::p[1]")).getText();
    System.out.println(p);
}
    public void Switchwindow()
    {
        String Parent = driver.getWindowHandle();
        Set<String> s=driver.getWindowHandles();
        Iterator<String> I1= s.iterator();
        while(I1.hasNext()) {
            String child_window = I1.next();

            if (!Parent.equals(child_window)) {
                driver.switchTo().window(child_window);
                System.out.println(driver.switchTo().window(child_window).getTitle());
                driver.close();
            }
        }
    }
//Hyperlink
public void Link()  {
    driver.findElement(By.xpath("//label[text()='Hyperlink']")).click();
    System.out.println("User navigated into the Hyperlink page");
    driver.findElement(By.xpath("//div[@class='hyperlink-wrap']/child::a[text()='Web browser automation']")).click();
    driver.manage().timeouts().pageLoadTimeout(60L, TimeUnit.SECONDS);
   String Parent= driver.getWindowHandle();
    Switchwindow();
    driver.switchTo().window(Parent);

    driver.findElement(By.xpath("//label[text()='Hyperlink']")).click();
    driver.findElement(By.xpath("//div[@class='hyperlink-wrap']/child::a[text()='Desktop automation']")).click();

      Switchwindow();
    // switch to parent window
    driver.switchTo().window(Parent);
    System.out.println("Back to Main window");
    driver.findElement(By.xpath("//label[text()='Hyperlink']")).click();
}
// Drop Down

    public void Dropdown()
    {
        driver.findElement(By.xpath("//ul//li//label[text()='Dropdown']")).click();
        String drop=driver.findElement(By.xpath("//div[@class='rghtside-inner' and @id='rghtsideinnerbox_7']/child::h2")).getText();
        System.out.println("The Dropdown page is title is :\n" +drop);
        String droptitle1=driver.findElement(By.xpath("(//div[@class=\"dropdown-wrap\"]//div//child::label)[1]")).getText();
        System.out.println("The first drop down title is:\t\t" +droptitle1);
        System.out.println("Selecy Country name");
        driver.findElement(By.xpath("//select[@name=\"countryname\"]")).click();
        driver.findElement(By.xpath("//div//select//option[@value='92']")).isSelected();
        System.out.println("India is selected");
        String droptitle2=driver.findElement(By.xpath("(//div[@class=\"dropdown-wrap\"]//div//child::label)[2]")).getText();
        System.out.println("The Second drop down title is:\t\t" +droptitle2);
        System.out.println("Select State Name");
        driver.findElement(By.xpath("//select[@name=\"statename\"]")).click();
        driver.findElement(By.xpath("//select[@name=\"statename\"]/child::option")).isSelected();
        System.out.println("State name is selected");

    }
    //drag and drop
        public void Drag()  {
        driver.findElement(By.xpath("//li//label[text()='Drag & Drop']")).click();
        //Actions class method to drag and drop
        Actions builder = new Actions(driver);

        WebElement from = driver.findElement(By.xpath("(//div[@class=\"ui-widget-content draggable-innr ui-draggable ui-draggable-handle\"]//p)[1]"));

        WebElement to = driver.findElement(By.xpath("(//div[@class=\"ui-widget-header dropable-innr ui-droppable\"]//p)[2]"));
        //Perform drag and drop

        builder.dragAndDrop(from, to).perform();

        System.out.println("Java is drag and dropped to javac");
        WebElement frm=driver.findElement(By.xpath("(//div[@class=\"ui-widget-content draggable-innr ui-draggable ui-draggable-handle\"]//p)[2]"));
        WebElement dropto=driver.findElement(By.xpath("(//div[@class=\"ui-widget-header dropable-innr ui-droppable\"]//p)[1]"));
        builder.dragAndDrop(frm,dropto).perform();
        System.out.println(" Python is drag and dropped to python.exe");


//        //verify text changed in to 'Drop here' box
//        String textTo = to.getText();
//
//        if(textTo.equals("Dropped!")) {
//            System.out.println("PASS: Source is dropped to target as expected");
//        }else {
//            System.out.println("FAIL: Source couldn't be dropped to target as expected");
//        }



    }
   // right click and alert pop up function
    public void Textmenu()
    {
      driver.findElement(By.xpath("//li//label[text()='Context Menu']")).click();
        System.out.println("Context menu page is displayed");
        //Instantiate Action Class
        Actions actions = new Actions(driver);

        //Retrieve WebElement to perform right click
        WebElement right = driver.findElement(By.xpath("//div[@id='hot-spot']"));
        //Right Click the button to display Context Menu&nbsp;
        actions.contextClick(right).perform();
        System.out.println("Right click Context Menu displayed");
        Alert alert=driver.switchTo().alert();
        System.out.println("Alert message is:\n" +alert.getText());
        driver.switchTo().alert().accept();
        Robot robot;
            try {
                robot = new Robot();
                robot.keyPress(KeyEvent.VK_ESCAPE);
            } catch (Throwable e) {
                throw new RuntimeException(e);
            }

            //Code to Enter D1.txt
            //Press Shify key

        System.out.println("alert popup is closed");


    }
    //double click and escape
    public void Double()
    {
        driver.findElement(By.xpath("//label[text()='Double Click']")).click();
        System.out.println("Double click page is clicked");
        String driverElement=driver.findElement(By.xpath("//div//p[@class='bg-info']")).getText();
        System.out.println(driverElement);
        Actions actions=new Actions(driver);
        WebElement doub=driver.findElement(By.xpath("//div[@class='doubleclick-wrap']"));
        actions.moveToElement(doub).doubleClick().build().perform();
          String  doubtext=driver.findElement(By.xpath("//div[@class='doubleclick-wrap']/child::div[@class='msgbox']")).getText();
         System.out.println("The message displayed after double click is:\t"+doubtext);
        // driver.close();
            }


    // frame
    public void Frame()
    {
        driver.findElement(By.xpath("//label[text()='Frames']")).click();
        System.out.println("Frame page is displayed");
        driver.findElement(By.xpath("//textarea[@id='tiny-frame']")).sendKeys("I am in Frame page");
      //  new Actions(driver).moveToElement((driver.findElement(By.xpath("//iframe[@name='frame-bottom']")))).perform();
        JavascriptExecutor js = (JavascriptExecutor)driver;
        js.executeScript("scrollBy(0, 3000)");
        driver.findElement(By.xpath(("//iframe[@name='frame-bottom']"))).click();
        WebElement frameElement=driver.findElement(By.xpath(("//iframe[@name='frame-bottom']")));
        driver.switchTo().frame(frameElement);
        String a=driver.findElement(By.xpath("//div[@id='sub-frame-error-details']")).getText();
        System.out.println( "The hover message is :\n"+a);
        if(a==null)
        {
            System.out.println("Test fail");
        }
        else {
            System.out.println("Test pass");
        }
        driver.switchTo().defaultContent();

    }
     // Windows
      public void Windows()
      {
          driver.findElement(By.xpath("//li//label[text()='Windows']")).click();
          driver.findElement(By.xpath("//a[text()='Click here']")).click();
          String Parent= driver.getWindowHandle();
          Switchwindow();
          driver.switchTo().window(Parent);
          driver.findElement(By.xpath("//label[text()='Scrolling']")).click();
          driver.findElement(By.xpath("(//input[@id='username'])[1]")).sendKeys("Tester");
          driver.findElement(By.xpath("(//input[@id='pwd'])[1]")).sendKeys("*******");
          driver.findElement(By.xpath("//label[ text()= ' Remember me']/following::input[@type='checkbox']")).click();
          WebElement l=driver.findElement(By.xpath("//div[@id='scrollingwrap-box']"));
          // Actions class with moveToElement()
          Actions a = new Actions(driver);
          a.moveToElement(l);
          a.perform();
          System.out.println("Element is scrolled");
          driver.findElement(By.xpath("//button[@id='submitbtn']")).click();
          System.out.println("form submitted");
      }

}
