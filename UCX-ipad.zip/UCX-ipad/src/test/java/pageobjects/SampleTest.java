package pageobjects;
import io.appium.java_client.MobileElement;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;


public class SampleTest {
    public static AndroidDriver<MobileElement> driver;
    public WebDriverWait wait;
    @BeforeMethod
    public void setup () throws MalformedURLException {
        DesiredCapabilities caps = new DesiredCapabilities();
        caps.setCapability("deviceName", "Nokia G20");
        caps.setCapability("udid", "399653JA1170900601"); //DeviceId from "adb devices" command
        caps.setCapability("platformName", "Android");
        caps.setCapability("platformVersion", "12");
        caps.setCapability("skipUnlock","true");
        //caps.setCapability("appPackage", "com.google.android .calculator");
        //caps.setCapability("appActivity","com.google.android.gms.common.api.googleApiActivity");
       // caps.setCapability("noReset","false");
        driver = new  AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), caps);
        wait = new WebDriverWait(driver, 10);
    }



    @Test
    public void basicTest () throws InterruptedException, IOException {



    }
    @AfterMethod
    public void exit(){
        driver.quit();
    }
}


